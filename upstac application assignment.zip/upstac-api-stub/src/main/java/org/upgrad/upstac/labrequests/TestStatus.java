package org.upgrad.upstac.labrequests;

public enum TestStatus {
	NEGATIVE,POSITIVE

}
