package org.upgrad.upstac;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UpstacApplication {

	public static void main(String[] args) {
		SpringApplication.run(UpstacApplication.class, args);
	}


}
