package org.upgrad.upstac.testrequests;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TestRequestFlowRepository extends JpaRepository<TestRequestFlow, Long>{

}
